'use strict';

const electron = require('electron'); //read module
const app = electron.app;
const BrowserWindow = electron.BrowserWindow;
const Menu = electron.Menu;
const dialog = electron.dialog;
const ipcMain = electron.ipcMain;

let mainWindow;

let menuTemplate = [{
  label: 'なんか',
  submenu: [
    {label: '設定', submenu: [
      {label:'39秒', click: function(){ timeChanged(39) } },
      {label:'3分9秒', click: function(){ timeChanged(3 * 60 + 9) } },
      {label:'39分', click: function(){ timeChanged(39 * 60) } }
    ]},
    {type: 'separator' },
    {label: '終了', accelerator: 'CmdOrCtrl+Q', click: function(){ app.quit(); } }
  ]
}];

let menu = Menu.buildFromTemplate(menuTemplate);
Menu.setApplicationMenu(menu);

function createMainWindow(){
  mainWindow = new BrowserWindow({width: 600, height: 600});
  mainWindow.loadURL('file://' + __dirname + '/index.html');
  // mainWindow.webContents.openDevTools(); //for debug
  mainWindow.on('closed', function(){ //attach event called when this window is closed
    mainWindow = null;
  });
}

function timeChanged(second){
  mainWindow.webContents.send('timeChanged', second);
}

app.on('ready', function(){
  createMainWindow();
});

app.on('window-all-closed',function(){
  if (process.platform !== 'darwin'){
    app.quit();
  }
});

app.on('activate',function(){
  if (mainWindow === null){
    createMainWindow();
  }
});
