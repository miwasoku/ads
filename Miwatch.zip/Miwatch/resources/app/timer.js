(function(){
  'use strict';

  var isRunning = false;
  var startTime;
  var targetTime = 3 * 60 + 9;
  var timerId;

  var btn = document.getElementById('timerbtn');
  var label = document.getElementById('timerLabel');
  var image = document.getElementById('image');

  var usual = 'miwa.png';
  var retire = 'retire.png';
  var die = 'die.png';

  var sound = 'saiko.wav';
  var stop = 'kita.wav'
  var run = 'denwa.wav';
  var gameover = 'gameover.wav';
  var audio = new Audio('audio/' + sound);
  audio.loop = true;
  var se = stop;

  const electron = require('electron');
  const ipcRenderer = electron.ipcRenderer;
  const remote = electron.remote;
  const Menu = remote.Menu;
  const MenuItem = remote.MenuItem;

  let menu = new Menu();
  menu.append(new MenuItem({ label: '39秒', click: function(){
    setTargetTime(39);
  }}));
  menu.append(new MenuItem({ label: '3分9秒', click: function(){
    setTargetTime(3 * 60 + 9);
  }}));
  menu.append(new MenuItem({ label: '39分', click: function(){
    setTargetTime(39 * 60);
  }}));
  window.addEventListener('contextmenu', function(e){
    if(isRunning){
      return ;
    }
    e.preventDefault();
    menu.popup(remote.getCurrentWindow());
  });

  ipcRenderer.on('timeChanged',function(event, second){
    if(isRunning){
      return ;
    }
    setTargetTime(second);
  });

  btn.addEventListener('click',function(){
    if(!isRunning){
      isRunning = true;
      setButtonState('green','辞表提出');
      setImage(retire);
      startTime = new Date();
      se = run;
      updateTimer();
    }else {
      setButtonState('red','連勤開始');
      setImage(usual);
      resetTimer();
      isRunning = false;
    }
  })

  image.addEventListener('click',function(){
    imageSound();
  })

  function updateTimer(){
    timerId = setTimeout(function(){
      var e = Date.now() - startTime; //elapsed time
      var esec = Math.floor(e / 1000);
      var remain = targetTime - esec;

      label.innerHTML = secToLabelFormat(remain);

      if(remain <= 0){ //finished
        timerFinished();
        return;
      }

      updateTimer();
    },500);
  }

  function resetTimer(){
    clearTimeout(timerId);
    label.innerHTML = secToLabelFormat(targetTime);
    audio.pause();
    audio.currentTime = 0;
    se = stop;
  }

  function timerFinished(){
    setButtonState('yellow','過労死♪');
    setImage(die);
    audio.play();
    se = gameover;
  }

  //example: 90s -> 1:30
  function secToLabelFormat(rawsec){
    var min = Math.floor(rawsec / 60);
    var sec = rawsec % 60;

    //("0"+num).slice(-2) -> 0:6 to 00:06 ref.evernote
    return ("0"+min).slice(-2) + ':' + ("0"+sec).slice(-2);
  }

  function setButtonState(className, labelText){
    btn.className = className;
    btn.innerHTML = labelText;
  }

  function setImage(pic){
    image.src = 'images/' + pic;
  }

  function setTargetTime(second){
    targetTime = second;
    label.innerHTML = secToLabelFormat(targetTime);
  }

  function imageSound(){
    var a = new Audio('audio/' + se);
    a.play();
  }
})();
